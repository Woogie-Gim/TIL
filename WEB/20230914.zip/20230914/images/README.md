# Django

> SSAFY 10기 Django 과정 라이브 강의 코드

| 진행일 | 주제                    |
| ------ | ----------------------- |
| 09/12  | Intro & Design Pattern  |
| 09/13  | Template & URLs         |
| 09/14  | Model                   |
| 09/15  | ORM                     |
| 09/25  | ORM with View           |
| 09/26  | Form                    |
| 09/27  | Static                  |
| 10/4   | Authentication System 1 |
| 10/5   | Authentication System 2 |
| 10/18  | Django REST Framwork 1  |
| 10/19  | Django REST Framwork 2  |

